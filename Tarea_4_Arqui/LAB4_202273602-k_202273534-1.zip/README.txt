Miguel Huerta	202273602-K	P201
Sebastián Muñoz 202273534-1	P201

Instrucciones de uso:
	-Al inicio del codigo hay 3 variables, f, x y n. Las cuales deben ser modificadas
	para ver cada caso de prueba.
	-La variable n es utilizada para la funcion fuumo o la funcion aureo.

Detalles:
	-No pudimos lograr hacer la recursividad (completamente) para ninguna de las 2 funciones,
	la funcion 1 sirve para los casos en que no se entra a recursividad o cuando se entra 1 vez a la recursividad.
	-La funcion 2 no sirve para ningun caso.
	-La funcion 2, las operaciones con numeros flotantes se (trataron) de 
	resolver con las funciones proveidas por QtARMSim, las cuales se encuentran en la 
	pestaña "Help" de este programa.