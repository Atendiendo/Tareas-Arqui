Miguel Huerta	202273602-K	P201
Sebastián Muñoz 202273534-1	P201

Las entradas estan sujetas al reloj
Se tomo el supuesto de que despues del ultimo estado ("H") este regresa a (“I”)

Partimos con el display "I"

Algoritmos:
Se utilizo mapas de karnaugh.
Flip Flops tipo D.
