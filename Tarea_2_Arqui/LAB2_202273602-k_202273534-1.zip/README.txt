Miguel Huerta	202273602-k  Paralelo 201
Sebastián Muñoz	202273534-1  Paralelo 201

Se realizo la tabla de verdad usando 4 bits de entrada y 7 bits de salida.
Luego se realizo un mapa de Karnaugh para cada salida.
Finalmente se realiza el circuito 

Supuesto utilizado 
Inicio, 4, derecha, 1, arriba, 6, derecha, 3, abajo, 2, izquierda, 5, abajo,
6, derecha, fin